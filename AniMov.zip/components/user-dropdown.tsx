"use client"

import { useState, useRef, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Settings, LogOut, User, Heart, Clock, Users } from "lucide-react"
import Link from "next/link"

// Add this function at the top of the component, after the imports
const getInitials = (name: string) => {
  const words = name.trim().split(" ")
  if (words.length >= 2) {
    return (words[0].charAt(0) + words[1].charAt(0)).toUpperCase()
  }
  return words[0].charAt(0).toUpperCase()
}

interface UserDropdownProps {
  className?: string
}

export function UserDropdown({ className }: UserDropdownProps) {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isOpen])

  // Close dropdown on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsOpen(false)
      }
    }

    if (isOpen) {
      document.addEventListener("keydown", handleEscape)
    }

    return () => {
      document.removeEventListener("keydown", handleEscape)
    }
  }, [isOpen])

  const handleLogout = () => {
    // Handle logout logic here
    console.log("Logging out...")
    setIsOpen(false)
  }

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      {/* Avatar Button */}
      <Button
        variant="ghost"
        size="sm"
        className="p-1 rounded-full hover:bg-white/10"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Avatar className="w-8 h-8">
          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
          <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm">
            {getInitials("John Doe")}
          </AvatarFallback>
        </Avatar>
      </Button>

      {/* Dropdown Menu */}
      {isOpen && (
        <Card className="absolute right-0 top-full mt-2 w-64 bg-slate-900/95 backdrop-blur-md border-white/20 shadow-xl z-50">
          <CardContent className="p-0">
            {/* User Info */}
            <div className="p-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <Avatar className="w-12 h-12">
                  <AvatarImage src="/placeholder.svg?height=48&width=48" alt="User" />
                  <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                    {getInitials("John Doe")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-white font-semibold">John Doe</h3>
                  <p className="text-gray-400 text-sm">@johndoe</p>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="p-4 border-b border-white/10">
              <div className="grid grid-cols-3 gap-4 text-center">
                <Link href="/watchlist" onClick={() => setIsOpen(false)}>
                  <div className="hover:bg-white/10 rounded-lg p-2 transition-colors cursor-pointer">
                    <Clock className="h-5 w-5 text-blue-400 mx-auto mb-1" />
                    <div className="text-white font-semibold text-sm">24</div>
                    <div className="text-gray-400 text-xs">Watchlist</div>
                  </div>
                </Link>
                <Link href="/favorites" onClick={() => setIsOpen(false)}>
                  <div className="hover:bg-white/10 rounded-lg p-2 transition-colors cursor-pointer">
                    <Heart className="h-5 w-5 text-pink-400 mx-auto mb-1" />
                    <div className="text-white font-semibold text-sm">18</div>
                    <div className="text-gray-400 text-xs">Favorites</div>
                  </div>
                </Link>
                <Link href="/friends" onClick={() => setIsOpen(false)}>
                  <div className="hover:bg-white/10 rounded-lg p-2 transition-colors cursor-pointer">
                    <Users className="h-5 w-5 text-green-400 mx-auto mb-1" />
                    <div className="text-white font-semibold text-sm">12</div>
                    <div className="text-gray-400 text-xs">Friends</div>
                  </div>
                </Link>
              </div>
            </div>

            {/* Menu Items */}
            <div className="p-2">
              <Link href="/profile" onClick={() => setIsOpen(false)}>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-white/10 h-10"
                >
                  <User className="h-4 w-4" />
                  Profile
                </Button>
              </Link>

              <Link href="/settings" onClick={() => setIsOpen(false)}>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-3 text-gray-300 hover:text-white hover:bg-white/10 h-10"
                >
                  <Settings className="h-4 w-4" />
                  Settings
                </Button>
              </Link>

              <div className="border-t border-white/10 my-2" />

              <Button
                variant="ghost"
                className="w-full justify-start gap-3 text-red-400 hover:text-red-300 hover:bg-red-500/10 h-10"
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
